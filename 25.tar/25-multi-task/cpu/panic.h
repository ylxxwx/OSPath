#ifndef PANIC_H_
#define PANIC_H_

void panic(char *msg);

#endif
