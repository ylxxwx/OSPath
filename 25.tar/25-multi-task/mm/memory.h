#ifndef _MEMORY_H_
#define _MEMORY_H_

void init_memory();

#endif // _MEMORY_H_